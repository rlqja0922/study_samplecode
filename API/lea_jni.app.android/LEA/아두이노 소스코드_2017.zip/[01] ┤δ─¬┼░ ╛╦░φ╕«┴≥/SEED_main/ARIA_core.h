//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Implementation of ARIA Block Cipher on 8-bit AVR Processors (Balanced Optimization)							            //
// Copyright (C) 2016 KISA <http://seed.kisa.or.kr>                                                             //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef ARIA_CORE_H_
#define ARIA_CORE_H_

/*************** New Data Types *******************************************/
#define BYTE    unsigned char        //  1-BYTE data type

/*************************** Function Declarations ************************/
void Crypt(const BYTE *p, int R, const BYTE *e, BYTE *c);
int DecKeySetup(const BYTE *w0, BYTE *d, int keyBits);
int EncKeySetup(const BYTE *w0, BYTE *e, int keyBits);
void RotXOR (const BYTE *s, int n, BYTE *t);
void DL (const BYTE *i, BYTE *o);

void ARIA_Enc_Key(				/* key scheduling function for encryption*/
BYTE *pbUserKey,				// [in]			secret user key
BYTE *pdwRoundKey		 		// [out]		round keys for encryption or decryption
);

void ARIA_Dec_Key(				/* key scheduling function for decryption*/
BYTE *pbUserKey,				// [in]			secret user key
BYTE *pdwRoundKey		 		// [out]		round keys for encryption or decryption
);

void ARIA_Enc_DEC(				/* encryption/decryption function */
BYTE *pdwRoundKey,				// [in]			round keys for encryption
BYTE *pbData 					// [in,out]	data to be encrypted
);

#endif /* ARIA_CORE_H_ */
