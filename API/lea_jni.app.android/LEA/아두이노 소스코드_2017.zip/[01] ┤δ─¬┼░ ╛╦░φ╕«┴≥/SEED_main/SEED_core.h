//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Implementation of SEED Block Cipher on 8-bit AVR Processors (Balanced Optimization)                          //
// Copyright (C) 2016 KISA <http://seed.kisa.or.kr>                                                             //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef SEED_CORE_H_
#define SEED_CORE_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef unsigned long       DWORD;		// unsigned 4-byte data type
typedef unsigned short      WORD;		// unsigned 2-byte data type
typedef unsigned char       BYTE;		// unsigned 1-byte data type

/**************************** Constant Definitions ****************************/
#define NoRounds         16						// the number of rounds
#define NoRoundKeys      (NoRounds*2)			// the number of round-keys
#define SeedBlockSize    16    					// block length in bytes
#define SeedBlockLen     128   					// block length in bits

#define ROTL(x, n)     (((x) << (n)) | ((x) >> (32-(n))))		// left rotation
#define ROTR(x, n)     (((x) >> (n)) | ((x) << (32-(n))))		// right rotation

// macroses for converting endianess
#define EndianChange(dwS)                       \
( (ROTL((dwS),  8) & (DWORD)0x00ff00ff) |   \
(ROTL((dwS), 24) & (DWORD)0xff00ff00) )


/*************************** Function Declarations ****************************/

void SEED_Enc(		/* encryption function */
DWORD *pdwRoundKey,			// [in]			round keys for encryption
BYTE *pbData 				// [in,out]	data to be encrypted
);

void SEED_Dec(		/* decryption function */
DWORD *pdwRoundKey,			// [in]			round keys for decryption
BYTE *pbData 				// [in,out]	data to be decrypted
);

void SEED_Key(		/* key scheduling function */
BYTE *pbUserKey,				// [in]			secret user key
DWORD *pdwRoundKey		 		// [out]		round keys for encryption or decryption
);



#endif /* SEED_CORE_H_ */
