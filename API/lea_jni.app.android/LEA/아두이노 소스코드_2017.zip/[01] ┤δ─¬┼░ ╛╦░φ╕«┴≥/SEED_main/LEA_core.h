//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Implementation of LEA Block Cipher on 8-bit AVR Processors (Balanced Optimization)                           //
// Copyright (C) 2016 KISA <http://seed.kisa.or.kr>                                                             //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef LEA_CORE_H_
#define LEA_CORE_H_

typedef unsigned long DWORD;
typedef unsigned char BYTE;

#define ROR(W,i) (((W)>>(i)) | ((W)<<(32-(i))))
#define ROL(W,i) (((W)<<(i)) | ((W)>>(32-(i))))

#define DWORD_in(x)            (*(DWORD*)(x))
#define DWORD_out(x, v)        {*((DWORD*)(x)) = (v);}

void LEA_Key(BYTE pbUserKey[16],DWORD pdwRoundKey[24][6]);
void LEA_Enc(DWORD pdwRoundKey[24][6],BYTE pbData[16]);
void LEA_Dec(DWORD pdwRoundKey[24][6],BYTE pbData[16]);


#endif /* LEA_CORE_H_ */

